package br.unisana.appsoma

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val edtNum1 = findViewById<EditText>(R.id.edt_num1)
        val edtNum2 = findViewById<EditText>(R.id.edt_num2)
        val btnCalc = findViewById<Button>(R.id.btn_calc)
        val txvResultado = findViewById<TextView>(R.id.txv_resultado)

        btnCalc.setOnClickListener{
            val valor1: Double = edtNum1.text.toString().toDouble()
            val valor2: Double = edtNum2.text.toString().toDouble()
            val resultado: Double = valor1*valor2
            txvResultado.text = "O Valor da tensão é: $resultado"
    }
}
}